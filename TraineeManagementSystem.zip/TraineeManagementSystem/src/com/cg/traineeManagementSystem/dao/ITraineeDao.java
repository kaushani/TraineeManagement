package com.cg.traineeManagementSystem.dao;

import java.util.List;

import com.cg.traineeManagementSystem.bean.Trainee;

public interface ITraineeDao {

	void addTrainee(Trainee trainee);

	List<Trainee> getAllDetails();
	
	Trainee getTraineeById(int id);
	
	//void deleteTrainee(int id);
}
