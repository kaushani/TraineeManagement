package com.cg.traineeManagementSystem.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.traineeManagementSystem.bean.Trainee;


@Repository

public class TraineeDaoImpl implements ITraineeDao {

	
	
	@PersistenceContext
	private EntityManager entityManager;

	
	@Override
	public void addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		entityManager.persist(trainee);
		entityManager.flush();
	}


	@Override
	public List<Trainee> getAllDetails() {
		// TODO Auto-generated method stub
		TypedQuery<Trainee> query = entityManager.createQuery("SELECT trainee FROM Trainee trainee", Trainee.class);
		return query.getResultList();
	}


	@Override
	public Trainee getTraineeById(int id) {
		// TODO Auto-generated method stub
		return entityManager.find(Trainee.class, id);

	}


	
}
