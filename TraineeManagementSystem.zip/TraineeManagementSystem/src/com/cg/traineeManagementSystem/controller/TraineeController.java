package com.cg.traineeManagementSystem.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.traineeManagementSystem.bean.Trainee;
import com.cg.traineeManagementSystem.service.ITraineeService;






@Controller
public class TraineeController {
	
	@Autowired
	private ITraineeService obService;

	public ITraineeService getObService() {
		return obService;
	}

	public void setObService(ITraineeService obService) {
		this.obService = obService;
	}
	@RequestMapping("/showLogin")
	public String showLogin() {
		// Create an attribute of type Question
		return "login";
	}
	@RequestMapping("/loginValidation")
	public String test(@RequestParam("name") String name,
		@RequestParam("pwd") String pass,Model m)
	{
		if(name.equals("admin") && pass.equals("password"))
			return "Home";
		else
			return "login";
	}
	@RequestMapping("/showAddTrainee")
	public ModelAndView showAddDonation() 
	{
		// Create an attribute of type Question
		Trainee trainee=new Trainee();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("addTrainee", "trainee", trainee);
	}
	@RequestMapping("/showHome")
	public String showHome() {
		// Create an attribute of type Question
		return "Home";
	}
	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("trainee") @Valid Trainee trainee,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			obService.addTrainee(trainee);
			mv = new ModelAndView("Success");
			
		} else {
			mv = new ModelAndView("addTrainee", "trainee", trainee);
		}

		return mv;
	}
	@RequestMapping("/showTrainee")
	public ModelAndView showTrainee() {

		ModelAndView mv = new ModelAndView();

		List<Trainee> list = obService.getAllDetails();

			mv.setViewName("ShowTrainee");
			// Add the attribute to the model
			mv.addObject("list", list);
	
		return mv;
	}
	@RequestMapping("viewTraineeById")
	public ModelAndView showTraineeForm()
	{
		Trainee trainee= new Trainee();
		ModelAndView mv= new ModelAndView("showTraineeById");
		mv.addObject("trainee", trainee);
		mv.addObject("isfirst", true);
		return mv;
		
	}
	@RequestMapping("/showTraineeById")
	public ModelAndView showTraineeById(@ModelAttribute("trainee") Trainee trainee)
	{
		System.out.println("hii");
		ModelAndView mv= new ModelAndView();
		Trainee list= new Trainee();
		list= obService.getTraineeById(trainee.getId());
		if(list!=null)
		{
			mv.setViewName("showTraineeById");
			mv.addObject("list", list);
		}
		else
		{
			String msg="Enter a valid ID!!!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	
}
