package com.cg.traineeManagementSystem.service;

import java.util.List;

import com.cg.traineeManagementSystem.bean.Trainee;

public interface ITraineeService {

	void addTrainee(Trainee trainee);

	List<Trainee> getAllDetails();
	
	Trainee getTraineeById(int id);
}
