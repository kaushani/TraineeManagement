package com.cg.traineeManagementSystem.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.traineeManagementSystem.bean.Trainee;
import com.cg.traineeManagementSystem.dao.ITraineeDao;

@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	ITraineeDao obDao;
	
	
	
	public ITraineeDao getObDao() {
		return obDao;
	}



	public void setObDao(ITraineeDao obDao) {
		this.obDao = obDao;
	}



	@Override
	public void addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		obDao.addTrainee(trainee);
	}



	@Override
	public List<Trainee> getAllDetails() {
		// TODO Auto-generated method stub
		return obDao.getAllDetails();
	}



	@Override
	public Trainee getTraineeById(int id) {
		// TODO Auto-generated method stub
		return obDao.getTraineeById(id);
	}

	
}
